# FAQ / WIKI

This is the official **Android-Iconics** FAQ/Wiki. People can contribute to it through pull requests.
Each question and it's answer is hosted in a separate file within the FAQ folder.

## Overview

* [TextView crashes with IOOBE using the IconicsLayoutInflator2](FAQ/textview_ioobe.md)